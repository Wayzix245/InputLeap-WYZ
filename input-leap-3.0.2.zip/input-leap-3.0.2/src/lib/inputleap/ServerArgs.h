/*
 * InputLeap -- mouse and keyboard sharing utility
 * Copyright (C) 2014-2016 Symless Ltd.
 *
 * This package is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * found in the file LICENSE that should have accompanied this file.
 *
 * This package is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "inputleap/ArgsBase.h"

namespace inputleap {

class Config;

class ServerArgs : public ArgsBase {
public:
    ServerArgs();

public:
    std::string m_configFile;
    Config* m_config;
    std::string m_screenChangeScript;
    bool check_client_certificates = true;
    bool enable_auto_display_switch = false;
    std::string target_client_name;
    std::string target_local_display;
};

} // namespace inputleap
